<style>
#footer_left
{
	width: 40%;
	height: 100%;
	float: left;
	margin-left: 5%;
}
#footer_left a{
	text-decoration:none;
	color:#FFF;	}
#footer_left i{
    color:#F36;}
#footer_center
{
	width: 17%;
	height: 100%;
	float: left;
	margin-left: 1%;
}
#footer_center2
{
    width: 17%;
	height: 100%;
    float: left;
	margin-left: 1%;
}
#footer_right
{
    width: 17%;
	height: 100%;
	float: left;
	margin-left: 1%;
}
</style>
<div style="height: 80%;width:100%">
    <div id="footer_left">
        <H3 style="color:#F36">Contact information</H3>
        <h4><Address style="color:#F99;">
        Address: <a href="#">273 An Duong Vuong, Ward 3, District 5, Ho Chi Minh City, Vietnam</a><br>
        Phone: <a href="#">+(037)2865166</a><br>
        Email: <a href="#">nhom2@gmail.com</a><br>
        </Address> </h4>
        <p>
        <div id="socialMedia" style="width: 100%;height: 20px;">
            <a href="#facebook"><i class="fab fa-facebook-f"></i></a>
            <a href="#twitter"><i class="fab fa-twitter"></i></a>    
            <a href="#instagram"><i class="fab fa-instagram"></i></a>
            <a href="#google"><i class="fab fa-youtube"></i></a>                            
        </div>
        </p>           
    </div>
    <div id="footer_center">
        <h3 style="color:#F36"> Company</h3>
	    <i>
            About Us <br>
            Blog Posts <br>
            Services <br>
            Pricing <br>
        </i>
    </div>
    <div id="footer_center2">
        <h3 style="color:#F36;"> Support</h3>
        <i>
            All Parfume <br>
            Care Advices <br>
            Care Support <br>
            Veterinary Help <br>
        </i>
    </div>
    <div id="footer_right">
        <h3 style="color:#F36;"> Quick Links</h3>
        <i>
            Contact Us <br>
            Create account <br>
            Care Center <br>
            Site Feedack <br>
        </i>
    </div>
</div>